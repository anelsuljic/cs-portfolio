var searchData=
[
  ['huecos_0',['Huecos',['../classProcesador.html#a4c52b690c701e23c59cac11f19ad3828',1,'Procesador']]]
];
