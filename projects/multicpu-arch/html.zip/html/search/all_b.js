var searchData=
[
  ['rechazados_0',['rechazados',['../structPendientes_1_1Prioridad.html#aacd2f33dd1105fe9c8c6a0078b2e38e4',1,'Pendientes::Prioridad']]]
];
