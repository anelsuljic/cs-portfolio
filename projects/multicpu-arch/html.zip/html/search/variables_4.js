var searchData=
[
  ['mem_0',['Mem',['../classProcesador.html#ac8f1aa1911db9903c1fbe5bf5a0f3cfb',1,'Procesador']]]
];
