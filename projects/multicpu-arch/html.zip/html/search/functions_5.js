var searchData=
[
  ['leer_0',['leer',['../classCluster.html#a482d879edb37f72e49c13e9c3e6c4320',1,'Cluster::leer()'],['../classPendientes.html#a5e1d4a0943a872797754045ae3efbb7b',1,'Pendientes::leer()'],['../classProceso.html#ad133f53bba77755f779ef63b6e529cdb',1,'Proceso::leer()']]]
];
