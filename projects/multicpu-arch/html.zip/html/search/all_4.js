var searchData=
[
  ['hueco_0',['Hueco',['../structProcesador_1_1Hueco.html',1,'Procesador']]],
  ['huecos_1',['Huecos',['../classProcesador.html#a4c52b690c701e23c59cac11f19ad3828',1,'Procesador']]]
];
