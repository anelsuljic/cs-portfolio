var searchData=
[
  ['i_5fescribir_5festructura_0',['i_escribir_estructura',['../classCluster.html#aa25b7d5905b09e8bf7e31814144d604a',1,'Cluster']]],
  ['i_5fleer_1',['i_leer',['../classCluster.html#a18370f05c2cb633c9929b2cd6c01d676',1,'Cluster']]],
  ['i_5fmodificar_5fcluster_2',['i_modificar_cluster',['../classCluster.html#af2bd2dc8a9326a967cad6014a34e1c5e',1,'Cluster']]],
  ['id_3',['id',['../classProcesador.html#a4589bb19af9315e4fa55e8f09f9ae9bd',1,'Procesador::id()'],['../classProceso.html#aedb36cca995b8b23d2e3d3739d30b216',1,'Proceso::id()']]]
];
