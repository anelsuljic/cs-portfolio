var searchData=
[
  ['enviados_0',['enviados',['../structPendientes_1_1Prioridad.html#a188457973f8c3d598a1d98fd3008c8dc',1,'Pendientes::Prioridad']]],
  ['estructura_1',['Estructura',['../classCluster.html#a0e4302e6218471e944ff74e5ac8f0207',1,'Cluster']]]
];
