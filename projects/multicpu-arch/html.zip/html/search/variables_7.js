var searchData=
[
  ['pos_5fini_0',['pos_ini',['../structProcesador_1_1Hueco.html#a1fe95308a0172d78a1f44e044f2b4f40',1,'Procesador::Hueco']]],
  ['procesadores_1',['Procesadores',['../classCluster.html#a4b590440ee951b692063c3306a0466df',1,'Cluster']]],
  ['procesos_2',['Procesos',['../structPendientes_1_1Prioridad.html#a41bd0cea0b6182f8ccc10791da2032be',1,'Pendientes::Prioridad::Procesos()'],['../classProcesador.html#a4d6febaf66e15e3a0614b4b491f3a94e',1,'Procesador::Procesos()']]]
];
