var searchData=
[
  ['tam_0',['tam',['../classProcesador.html#ac1e67449c8ac8024079240add4f91e94',1,'Procesador::tam()'],['../structProcesador_1_1Hueco.html#a0b98bcee485ec25b82537633778f1167',1,'Procesador::Hueco::tam()'],['../classProceso.html#a8093d3ce9269684378e5ccdab26396dc',1,'Proceso::tam()']]],
  ['teje_1',['teje',['../classProceso.html#a9cd4ea767e03a19f9c1e94d43d590a53',1,'Proceso']]]
];
