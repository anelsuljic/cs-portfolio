var searchData=
[
  ['tiene_5fprocesos_0',['tiene_procesos',['../classProcesador.html#af43db3ddfe98258796650e07a8bec6e9',1,'Procesador']]]
];
