var searchData=
[
  ['pendientes_0',['Pendientes',['../classPendientes.html#a62ebdea968572aa62e02a864544e31ac',1,'Pendientes']]],
  ['procesador_1',['Procesador',['../classProcesador.html#aacfa2a06c7d44636ecfb0338bebbfa8b',1,'Procesador::Procesador()'],['../classProcesador.html#a4c50b36667dad1a259aca784b6a819fe',1,'Procesador::Procesador(const string &amp;id, int tam)']]],
  ['proceso_2',['Proceso',['../classProceso.html#a632f57d6ec48e76c80fbeb7734c1148c',1,'Proceso::Proceso()'],['../classProceso.html#a33890ff17e1c48123823c42f66600109',1,'Proceso::Proceso(int tam)']]]
];
