var searchData=
[
  ['baja_5fprioridad_0',['baja_prioridad',['../classPendientes.html#acdfb5b687d76014f36019c55a0ea102e',1,'Pendientes']]],
  ['baja_5fproceso_1',['baja_proceso',['../classProcesador.html#a3e8e6f6e93c0b4306fd6f85b2d238f57',1,'Procesador']]],
  ['baja_5fproceso_5fmemoria_2',['baja_proceso_memoria',['../classProcesador.html#a8f3e0e532df7719896f403c25aab9854',1,'Procesador']]],
  ['baja_5fproceso_5fprocesador_3',['baja_proceso_procesador',['../classCluster.html#a223728a9bc84076c716e13540f9ed299',1,'Cluster']]]
];
