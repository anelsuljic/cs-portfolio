var searchData=
[
  ['ocup_0',['ocup',['../classProcesador.html#a63e2630538bd5adc4babebeea33a2adf',1,'Procesador']]],
  ['operator_3c_1',['operator&lt;',['../structProcesador_1_1Hueco.html#aff2f783ffe55a728f486301208ac29f2',1,'Procesador::Hueco']]]
];
