var searchData=
[
  ['alta_5fprioridad_0',['alta_prioridad',['../classPendientes.html#a5241da20d99c07996137dde428d715cf',1,'Pendientes']]],
  ['alta_5fproceso_1',['alta_proceso',['../classCluster.html#a70971b3510c7bd153a134fdcbbb7a5c6',1,'Cluster::alta_proceso()'],['../classPendientes.html#a9f2254c43c87986a14694c3f48dc8970',1,'Pendientes::alta_proceso()'],['../classProcesador.html#a43ad2c842684338378cd196fef6c844c',1,'Procesador::alta_proceso()']]],
  ['alta_5fproceso_5fprocesador_2',['alta_proceso_procesador',['../classCluster.html#a382908ec057560971ab55afe4bb27de4',1,'Cluster']]],
  ['avanzar_5ftiempo_3',['avanzar_tiempo',['../classCluster.html#a84a678b350532ff2065c15afe111f181',1,'Cluster::avanzar_tiempo()'],['../classProcesador.html#a940174a8a8527402e5b887294c8f77bf',1,'Procesador::avanzar_tiempo()'],['../classProceso.html#a7cf5e634bf6f45e77b77e9e42167ddf0',1,'Proceso::avanzar_tiempo()']]]
];
