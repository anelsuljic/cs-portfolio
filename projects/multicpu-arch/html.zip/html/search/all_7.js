var searchData=
[
  ['main_0',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['mem_1',['Mem',['../classProcesador.html#ac8f1aa1911db9903c1fbe5bf5a0f3cfb',1,'Procesador']]],
  ['modificar_5fcluster_2',['modificar_cluster',['../classCluster.html#a6b28634971702a4215479248826d9368',1,'Cluster']]]
];
