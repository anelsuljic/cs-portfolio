var searchData=
[
  ['area_0',['Area',['../classPendientes.html#acf73c85a563aa5b83ce6fa1cb09fe2c8',1,'Pendientes']]]
];
