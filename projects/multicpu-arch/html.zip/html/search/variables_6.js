var searchData=
[
  ['ocup_0',['ocup',['../classProcesador.html#a63e2630538bd5adc4babebeea33a2adf',1,'Procesador']]]
];
