var searchData=
[
  ['hueco_0',['Hueco',['../structProcesador_1_1Hueco.html',1,'Procesador']]]
];
