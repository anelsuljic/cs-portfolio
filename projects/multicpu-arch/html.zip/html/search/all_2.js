var searchData=
[
  ['cluster_0',['Cluster',['../classCluster.html',1,'Cluster'],['../classCluster.html#aee7feb1d599d4c8fda6c3ee83e86ba81',1,'Cluster::Cluster()']]],
  ['cluster_2ecc_1',['Cluster.cc',['../Cluster_8cc.html',1,'']]],
  ['cluster_2ehh_2',['Cluster.hh',['../Cluster_8hh.html',1,'']]],
  ['compactar_5fmemoria_3',['compactar_memoria',['../classCluster.html#a622839c3b8dc923dc36f6026f35db269',1,'Cluster::compactar_memoria()'],['../classProcesador.html#a06b0b1c913b359a1bc6c920120dd0e66',1,'Procesador::compactar_memoria()']]],
  ['compactar_5fmemoria_5fprocesador_4',['compactar_memoria_procesador',['../classCluster.html#ad7d0cfde36df0ab681892121d0e96aad',1,'Cluster']]],
  ['consultar_5fid_5',['consultar_id',['../classProcesador.html#a3caaa26dfe5132fb7fc6b58f28c00343',1,'Procesador::consultar_id()'],['../classProceso.html#a33b52579d6ee93986d33341bacc86521',1,'Proceso::consultar_id() const']]],
  ['consultar_5fmemoria_6',['consultar_memoria',['../classProceso.html#a55976a19b8d909276c62e8be10036df5',1,'Proceso']]],
  ['consultar_5fmemoria_5flibre_7',['consultar_memoria_libre',['../classProcesador.html#a6926d998ba3071e7879d38914e49edc8',1,'Procesador']]],
  ['consultar_5ftiempo_8',['consultar_tiempo',['../classProceso.html#a4816bee1b97d41126160494109f84c42',1,'Proceso']]],
  ['contiene_5fproceso_9',['contiene_proceso',['../classProcesador.html#a367a4add30409ebfad49bd69b15547c9',1,'Procesador']]]
];
