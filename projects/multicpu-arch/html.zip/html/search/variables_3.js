var searchData=
[
  ['id_0',['id',['../classProcesador.html#a4589bb19af9315e4fa55e8f09f9ae9bd',1,'Procesador::id()'],['../classProceso.html#aedb36cca995b8b23d2e3d3739d30b216',1,'Proceso::id()']]]
];
