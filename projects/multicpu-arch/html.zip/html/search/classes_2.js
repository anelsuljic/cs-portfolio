var searchData=
[
  ['pendientes_0',['Pendientes',['../classPendientes.html',1,'']]],
  ['prioridad_1',['Prioridad',['../structPendientes_1_1Prioridad.html',1,'Pendientes']]],
  ['procesador_2',['Procesador',['../classProcesador.html',1,'']]],
  ['proceso_3',['Proceso',['../classProceso.html',1,'']]]
];
